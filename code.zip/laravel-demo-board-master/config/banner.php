<?php

return [
    'price' => env('BANNER_COST_PER_MILE')
];