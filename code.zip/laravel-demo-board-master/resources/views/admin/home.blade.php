@extends('layouts.app')

@section('content')
    @include ('admin._nav', ['page' => ''])
@endsection